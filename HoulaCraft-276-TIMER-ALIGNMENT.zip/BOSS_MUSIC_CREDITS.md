# HoulaCraft 275 — Musiques de combat RPG

Les compositions restent les œuvres de leurs auteurs. Leur présence ne signifie pas un soutien au projet.
**Featuring Music by Matthew Pablo**

Adaptations communes : conversion stéréo 44,1 kHz Ogg Vorbis qualité 3 et normalisation EBU R128 vers −19 LUFS. Pistes complètes conservées, sans coupe. Krampus et Champion reçoivent seulement des rampes de 2 ms aux extrémités pour réduire les clics de raccord ; aucun fondu long.

## Archange — Battle RPG Theme (variation OGG)

Music by Cleyton Kauffman - https://soundcloud.com/cleytonkauffman

- Auteur : Cleyton Kauffman — https://soundcloud.com/cleytonkauffman
- Page de la composition : https://opengameart.org/content/boss-battle-theme
- Téléchargement source : https://opengameart.org/sites/default/files/CleytonRX%20-%20Battle%20RPG%20Theme%20Var_0.ogg
- Licence : CC0 1.0 — https://creativecommons.org/publicdomain/zero/1.0/
- Source SHA-256 : `9a63f74305f5cbce8374a72a027a645c07c97663255aba0b817bc1f70c432ed5`
- OGG SHA-256 : `02438a6676985c684a2d9afdcc3760bd7c16fcc0ad59eeb2b632e4209a83ee47`
- Durée décodée : 114.337573696 s ; 5042287 échantillons par canal.
- Adaptations : fichier complet, normalisation sonore, conversion Ogg Vorbis ; aucun montage musical. Rampes aux extrémités : 0 ms en entrée et 0 ms en sortie.
- Écoute par l’agent : non.

## Boss communautaire — Fighting is not an option (RPG Battle Theme II)

Music by Cleyton Kauffman - https://soundcloud.com/cleytonkauffman

- Auteur : Cleyton Kauffman — https://soundcloud.com/cleytonkauffman
- Page de la composition : https://opengameart.org/node/51807
- Téléchargement source : https://opengameart.org/sites/default/files/Fighting%20is%20not%20an%20option.ogg
- Licence : CC0 1.0 — https://creativecommons.org/publicdomain/zero/1.0/
- Source SHA-256 : `9730739f83f47247eb55d8acd7bac8e77725662c58adeb2d2cee3b48932d4b9f`
- OGG SHA-256 : `5bcad444db01209fed4fb97d0c443276564d7c4e673089a88d7828fce3e3f408`
- Durée décodée : 70.249070295 s ; 3097984 échantillons par canal.
- Adaptations : fichier complet, normalisation sonore, conversion Ogg Vorbis ; aucun montage musical. Rampes aux extrémités : 0 ms en entrée et 0 ms en sortie.
- Écoute par l’agent : non.

## Gardien des Ents — Battle Theme B for RPG

Battle Theme B for RPG — cynicmusic — https://cynicmusic.com — https://pixelsphere.org — CC0 1.0.

- Auteur : cynicmusic — https://cynicmusic.com
- Page de la composition : https://opengameart.org/content/battle-theme-b-for-rpg
- Téléchargement source : https://opengameart.org/sites/default/files/battleThemeB.mp3
- Licence : CC0 1.0 — https://creativecommons.org/publicdomain/zero/1.0/
- Source SHA-256 : `8476ce29692d8d317a7d79628af967448ec09d9f66efe692a597336c5cea2629`
- OGG SHA-256 : `4215decf53d4b3147abd13bb70f0dd5908124147dd6cacc5ff6b793a3dad9b34`
- Durée décodée : 66.037551020 s ; 2912256 échantillons par canal.
- Adaptations : fichier complet, normalisation sonore, conversion Ogg Vorbis ; aucun montage musical. Rampes aux extrémités : 0 ms en entrée et 0 ms en sortie.
- Écoute par l’agent : non.

## Roi des Ents — Battle Theme A

Battle Theme A — cynicmusic — https://cynicmusic.com — https://pixelsphere.org — CC0 1.0.

- Auteur : cynicmusic — https://cynicmusic.com
- Page de la composition : https://opengameart.org/content/battle-theme-a
- Téléchargement source : https://opengameart.org/sites/default/files/battleThemeA.mp3
- Licence : CC0 1.0 — https://creativecommons.org/publicdomain/zero/1.0/
- Source SHA-256 : `6042399782e581d753d616bc703e66483d5eccb5fb687a20c9a552d68c49e620`
- OGG SHA-256 : `c8765b02474845f4ee51a9b31e00aed6846ee19b52e5ad856e7e1af9af66e874`
- Durée décodée : 95.851836735 s ; 4227066 échantillons par canal.
- Adaptations : fichier complet, normalisation sonore, conversion Ogg Vorbis ; aucun montage musical. Rampes aux extrémités : 0 ms en entrée et 0 ms en sortie.
- Écoute par l’agent : non.

## Krampus — Boss Battle #6 Metal (V1)

Boss Battle #6 Metal (V1) — nene — CC0 1.0.

- Auteur : nene — https://opengameart.org/content/boss-battle-6-metal
- Page de la composition : https://opengameart.org/content/boss-battle-6-metal
- Téléchargement source : https://opengameart.org/sites/default/files/Boss%20Battle%206%20Metal%20V1.wav
- Licence : CC0 1.0 — https://creativecommons.org/publicdomain/zero/1.0/
- Source SHA-256 : `a4b0ea3260293ac7fe6b8ab4903a4c43d1cefff504ddcb169cb109a3892d0e36`
- OGG SHA-256 : `7e5f37a74b874a6150d48cdbaf335960027d7f23cb24681ca07dbd065e033e68`
- Durée décodée : 52.363628118 s ; 2309236 échantillons par canal.
- Adaptations : fichier complet, normalisation sonore, conversion Ogg Vorbis ; aucun montage musical. Rampes aux extrémités : 2 ms en entrée et 2 ms en sortie.
- Écoute par l’agent : non.

## Reine des abeilles — Blackmoor Ninjas (No Vocals)

Featuring Music by Matthew Pablo — Blackmoor Ninjas (No Vocals) — https://www.matthewpablo.com — CC BY 3.0.

- Auteur : Matthew Pablo — https://www.matthewpablo.com
- Page de la composition : https://opengameart.org/content/blackmoor-ninjas-battle-theme
- Téléchargement source : https://opengameart.org/sites/default/files/Blackmoor%20Ninjas.zip
- Licence : CC BY 3.0 — https://creativecommons.org/licenses/by/3.0/
- Source SHA-256 : `76c17449c560431aa6b177cf2ddbc3eb2713cfd7ebd61bdcccc4397864cd0c57`
- OGG SHA-256 : `684b6b2118a0a463664a4ac71f0a0be16bf59198fe576cc823b7bc8d599a1358`
- Durée décodée : 131.944489796 s ; 5818752 échantillons par canal.
- Adaptations : fichier complet, normalisation sonore, conversion Ogg Vorbis ; aucun montage musical. Rampes aux extrémités : 0 ms en entrée et 0 ms en sortie.
- Écoute par l’agent : non.

La version **No Vocals** fournie par Matthew Pablo est utilisée. Conserver le crédit **Featuring Music by Matthew Pablo** dans la description publique du pack et le crédit auteur dans l’aide/crédits du jeu. La page source affiche CC BY 3.0 ; son ancien lien de consignes https://www.matthewpablo.com/services renvoyait HTTP 404 lors de la recherche.

## Souverain des ombres — Showdown of Misdeeds

"Showdown of Misdeeds" Composed by Jonathan Shaw (www.jshaw.co.uk) — CC BY 3.0.

- Auteur : Jonathan Shaw — https://www.jshaw.co.uk
- Page de la composition : https://opengameart.org/content/showdown-of-misdeeds-rpg-orchestral-essentials-boss-music
- Téléchargement source : https://opengameart.org/sites/default/files/showdown_of_misdeeds_mp3.zip
- Licence : CC BY 3.0 — https://creativecommons.org/licenses/by/3.0/
- Source SHA-256 : `3a38ae3a0c5a672302424ac26215517239a2fdef0a6f664b21d7250536ed3d5c`
- OGG SHA-256 : `ea0eed6450747aabf3ff9952b08c7536f6f9bce3d747ed4907fe0280ec2d25c3`
- Durée décodée : 221.100408163 s ; 9750528 échantillons par canal.
- Adaptations : fichier complet, normalisation sonore, conversion Ogg Vorbis ; aucun montage musical. Rampes aux extrémités : 0 ms en entrée et 0 ms en sortie.
- Écoute par l’agent : non.

Crédit demandé : **"Showdown of Misdeeds" Composed by Jonathan Shaw (www.jshaw.co.uk)**.

## Champion des vagues — JRPG Epic Rock Battle Theme #1

JRPG Epic Rock Battle Theme #1 — HydroGene — CC0 1.0.

- Auteur : HydroGene — https://opengameart.org/users/hydrogene
- Page de la composition : https://opengameart.org/content/jrpg-epic-rock-battle-theme-1
- Téléchargement source : https://opengameart.org/sites/default/files/jrpg_battle_full_0.mp3
- Licence : CC0 1.0 — https://creativecommons.org/publicdomain/zero/1.0/
- Source SHA-256 : `811ae1740c3f4875f860f5f22e415bd56674605aa856de6d1bb09634b951729f`
- OGG SHA-256 : `c248c7e4f42fa5644fbc2392944621d84841144064031306f5df439a1d7f712d`
- Durée décodée : 115.292879819 s ; 5084416 échantillons par canal.
- Adaptations : fichier complet, normalisation sonore, conversion Ogg Vorbis ; aucun montage musical. Rampes aux extrémités : 2 ms en entrée et 2 ms en sortie.
- Écoute par l’agent : non.

## Validation et réutilisation

Huit sources locales vérifiées par SHA-256, licences vérifiées dans les pages auteur déjà archivées, décodage intégral, comptage d’échantillons et mesure du niveau sonore après conversion. Aucune écoute subjective ni validation de raccord en jeu n’est revendiquée.
Les amorces, fins et éventuelles pauses originales sont conservées. Le Champion utilise la version complète approuvée avec introduction, qui revient à chaque répétition.
Les pistes CC BY ne sont pas relicenciées comme musique exclusive HoulaCraft. Conserver auteur, source, licence et mention des adaptations lors de la redistribution. Les crédits CC0 sont conservés volontairement.
