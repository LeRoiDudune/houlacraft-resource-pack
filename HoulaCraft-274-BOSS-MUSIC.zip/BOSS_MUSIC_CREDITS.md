# HoulaCraft — Boss music credits

The music remains the work of the credited composers. Their inclusion does not imply endorsement.
These compositions are used as synchronized combat music in the HoulaCraft resource pack.
No music from the Dark Souls soundtrack is included.

## archangel — The Summoning

'The Summoning' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au

- Source: https://www.scottbuckley.com.au/library/the-summoning/
- License: CC-BY-4.0 — https://creativecommons.org/licenses/by/4.0/
- Adaptations: stereo 44.1 kHz Ogg Vorbis, two-pass loudness normalization, 10 ms/20 ms edge fades; leading silence removed 0.000000 s; trailing silence removed 1.159070 s.
- Final decoded duration: 204.223718821 seconds; 9006266 samples/channel.

## community — Epic Boss Battle

Epic Boss Battle — Juhani Junkala (SubspaceAudio). CC0-1.0.

- Source: https://opengameart.org/content/boss-battle-music
- License: CC0-1.0 — https://creativecommons.org/publicdomain/zero/1.0/
- Adaptations: stereo 44.1 kHz Ogg Vorbis, two-pass loudness normalization, 10 ms/20 ms edge fades; leading silence removed 0.000000 s; trailing silence removed 0.000000 s.
- Final decoded duration: 123.428594104 seconds; 5443201 samples/channel.

## ent_guardian — Battle Theme

Battle Theme — Theodore Kerr (Wolfgang_). CC0-1.0.

- Source: https://opengameart.org/content/battle-theme-0
- License: CC0-1.0 — https://creativecommons.org/publicdomain/zero/1.0/
- Adaptations: stereo 44.1 kHz Ogg Vorbis, two-pass loudness normalization, 10 ms/20 ms edge fades; leading silence removed 0.000000 s; trailing silence removed 1.858005 s.
- Final decoded duration: 114.256281179 seconds; 5038702 samples/channel.

## ent_king — Boss Theme: Arcanos, Sorcerer of the Old Banished Woods

Boss Theme: Arcanos, Sorcerer of the Old Banished Woods — Philémon Weber (Helmet). CC-BY-4.0.

- Source: https://opengameart.org/content/dark-souls-type-boss-theme
- License: CC-BY-4.0 — https://creativecommons.org/licenses/by/4.0/
- Adaptations: stereo 44.1 kHz Ogg Vorbis, two-pass loudness normalization, 10 ms/20 ms edge fades; leading silence removed 0.000000 s; trailing silence removed 3.412245 s.
- Final decoded duration: 244.796281179 seconds; 10795516 samples/channel.

## krampus — Juggernaut

'Juggernaut' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au

- Source: https://www.scottbuckley.com.au/library/juggernaut/
- License: CC-BY-4.0 — https://creativecommons.org/licenses/by/4.0/
- Adaptations: stereo 44.1 kHz Ogg Vorbis, two-pass loudness normalization, 10 ms/20 ms edge fades; leading silence removed 0.700000 s; trailing silence removed 0.000000 s.
- Final decoded duration: 221.323038549 seconds; 9760346 samples/channel.

## queen_bee — Dark Descent

Music by Matthew Pablo — Dark Descent. www.matthewpablo.com. CC-BY 3.0.

- Source: https://opengameart.org/content/dark-descent
- License: CC-BY-3.0 — https://creativecommons.org/licenses/by/3.0/
- Adaptations: stereo 44.1 kHz Ogg Vorbis, two-pass loudness normalization, 10 ms/20 ms edge fades; leading silence removed 0.000000 s; trailing silence removed 3.924830 s.
- Final decoded duration: 79.405782313 seconds; 3501795 samples/channel.

Music by Matthew Pablo — www.matthewpablo.com.
Public pack/project description credit: **Featuring Music by Matthew Pablo**.
The track page supplies CC-BY 3.0. The author’s historical services page requests a credits-screen credit and distribution-description credit; the page returned HTTP 404 when the evidence was fetched.
For this project retain the credit above in the in-game credits/help and in the public pack description.

## shadow_sovereign — Eyes In The Void

'Eyes In The Void' by Scott Buckley - released under CC-BY 4.0. www.scottbuckley.com.au

- Source: https://www.scottbuckley.com.au/library/eyes-in-the-void/
- License: CC-BY-4.0 — https://creativecommons.org/licenses/by/4.0/
- Adaptations: stereo 44.1 kHz Ogg Vorbis, two-pass loudness normalization, 10 ms/20 ms edge fades; leading silence removed 0.807982 s; trailing silence removed 0.000000 s.
- Final decoded duration: 263.257913832 seconds; 11609674 samples/channel.

## wave_champion — The Final Battle

The Final Battle — skrjablin. CC0-1.0.

- Source: https://opengameart.org/content/the-final-battle
- License: CC0-1.0 — https://creativecommons.org/publicdomain/zero/1.0/
- Adaptations: stereo 44.1 kHz Ogg Vorbis, two-pass loudness normalization, 10 ms/20 ms edge fades; leading silence removed 0.000000 s; trailing silence removed 0.000000 s.
- Final decoded duration: 145.821315193 seconds; 6430720 samples/channel.

## Attribution and reuse

For Scott Buckley tracks, retain the full credit, source link, license link and adaptation notice. Do not redistribute the music as a standalone music product or submit it to music streaming/fingerprinting services. If publishing videos that feature these tracks, credit Scott Buckley in the video description.
Author conditions: https://www.scottbuckley.com.au/library/using-this-music/ and https://www.scottbuckley.com.au/library/licensing/ .

Philémon Weber (Helmet) is the author attribution supplied by the Arcanos source page.
Credit for the CC0 tracks is voluntary and retained here for traceability.
CC-BY music is not relicensed as exclusive HoulaCraft content. Keep the licenses and credits with redistributed music.

Technical validation used full decodes, sample counts, EBU R128 measurements and hashes. No subjective listening or in-game playback validation is claimed. The short edge fades are not a guarantee of a musically seamless loop; the source author describes The Final Battle as having an audible pause.
